The GRIMA Database of X-ray images
Machine Intelligence Group (GRIMA)
Department of Computer Science
Pontificia Universidad Catolica de Chile

   set: X100 <Sink strainer> 
images: 23
  size: 574 x 768 pixels
   fmt: bmp

Original Filenames: sequence E
Rotation of axis Z, R and T for 2 different Y.

<calibration object>
Images captured by Domingo Mery, 2000
YXLON, Hamburg, Germany

Position of Manipulator:
"Step= 0 X= 136001 Y= 188747 Z=-107874 T=-5772 R= 134980"
"Step= 1 X= 136001 Y= 188747 Z=-107873 T=-41709 R= 134980"
"Step= 2 X= 136001 Y= 188747 Z=-106875 T=-59470 R= 134980"
"Step= 3 X= 136001 Y= 188747 Z=-108868 T=-70336 R= 134980"
"Step= 4 X= 136001 Y= 188747 Z=-108873 T=-98063 R= 149980"
"Step= 5 X= 136001 Y= 188747 Z=-108873 T=-106788 R= 164977"
"Step= 6 X= 136001 Y= 188747 Z=-108873 T=-41369 R= 179979"
"Step= 7 X= 136001 Y= 188747 Z=-106874 T=-41369 R= 179980"
"Step= 8 X= 136001 Y= 188747 Z=-104876 T= 0 R= 179980"
"Step= 9 X= 136001 Y= 188747 Z=-104873 T= 0 R= 194979"
"Step= 10 X= 136001 Y= 188747 Z=-104873 T= 38751 R= 194995"
"Step= 11 X= 136001 Y= 188747 Z=-104873 T= 38751 R= 209993"
"Step= 12 X= 136001 Y= 188747 Z=-104873 T= 38751 R= 259974"
"Step= 13 X= 136001 Y= 188747 Z=-104873 T= 38751 R= 240002"
"Step= 14 X= 136001 Y= 187020 Z=-104873 T= 78690 R= 239975"
"Step= 15 X= 136001 Y= 187020 Z=-104873 T= 78690 R= 254974"
"Step= 16 X= 136001 Y= 187020 Z=-104873 T= 78690 R= 224987"
"Step= 17 X= 136001 Y= 187020 Z=-104873 T= 78690 R= 194994"
"Step= 18 X= 136001 Y= 187020 Z=-102874 T= 78690 R= 194975"
"Step= 19 X= 136001 Y= 187020 Z=-100870 T= 78690 R= 194975"
"Step= 20 X= 136001 Y= 187020 Z=-98878 T= 78690 R= 194975"
"Step= 21 X= 136001 Y= 187020 Z=-108870 T= 78690 R= 194975"
"Step= 22 X= 136001 Y= 187020 Z=-112867 T= 78690 R= 194975"
"Step= 23 X= 136001 Y= 187020 Z=-57137 T=-62875 R= 194975"


Contact: 
Domingo Mery
dmery@ing.puc.cl
http://dmery.ing.puc.cl

(c) All rights reserved. These images can be used for educational and research purposes only.

