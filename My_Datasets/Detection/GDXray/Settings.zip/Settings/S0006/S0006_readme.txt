The GRIMA Database of X-ray images
Machine Intelligence Group (GRIMA)
Department of Computer Science
Pontificia Universidad Catolica de Chile

   set: X102 <Sink strainer> 
images: 17
  size: 574 x 768 pixels
   fmt: bmp

Original Filenames: sequence F
Rotation of axis X, Y, Z, R and T

<calibration object>
Images captured by Domingo Mery, 2000
YXLON, Hamburg, Germany

Position of Manipulator:
"Step= 0 X= 98000 Y= 191543 Z=-111618 T=-62875 R= 194975"
"Step= 1 X= 98000 Y= 191543 Z=-111617 T=-62875 R= 148601"
"Step= 2 X= 98000 Y= 191543 Z=-111616 T=-62875 R= 125000"
"Step= 3 X= 98000 Y= 191543 Z=-111618 T= 4 R= 125000"
"Step= 4 X= 98000 Y= 191543 Z=-111614 T= 88873 R= 143848"
"Step= 5 X= 98000 Y= 191543 Z=-97366 T= 88873 R= 143848"
"Step= 6 X= 98000 Y= 191543 Z=-97363 T= 88873 R= 232090"
"Step= 7 X= 98000 Y= 191543 Z=-115816 T= 88873 R= 232090"
"Step= 8 X= 108139 Y= 191543 Z=-115817 T= 88873 R= 184228"
"Step= 9 X= 98000 Y= 191543 Z=-98356 T= 88873 R= 184228"
"Step= 10 X= 98000 Y= 182971 Z=-98354 T= 88873 R= 184228"
"Step= 11 X= 98000 Y= 185666 Z=-98353 T= 88873 R= 218394"
"Step= 12 X= 98000 Y= 185666 Z=-113279 T= 88873 R= 133540"
"Step= 13 X= 98000 Y= 185666 Z=-113277 T= 42064 R= 133540"
"Step= 14 X= 98000 Y= 185666 Z=-113278 T=-127119 R= 133540"
"Step= 15 X= 98000 Y= 185666 Z=-113276 T=-127119 R= 254908"
"Step= 16 X= 98000 Y= 185666 Z=-89533 T=-127119 R= 234247"

Contact: 
Domingo Mery
dmery@ing.puc.cl
http://dmery.ing.puc.cl

(c) All rights reserved. These images can be used for educational and research purposes only.

