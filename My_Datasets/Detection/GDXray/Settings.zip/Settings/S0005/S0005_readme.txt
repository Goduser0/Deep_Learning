The GRIMA Database of X-ray images
Machine Intelligence Group (GRIMA)
Department of Computer Science
Pontificia Universidad Catolica de Chile

   set: X101 <Sink strainer> 
images: 27
  size: 574 x 768 pixels
   fmt: bmp

Original Filenames: sequence K
Rotation of axis R

<calibration object>
Images captured by Domingo Mery, 2000
YXLON, Hamburg, Germany

Position of Manipulator:
"Step= 0 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-104890"
"Step= 1 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-94890"
"Step= 2 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-84890"
"Step= 3 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-74890"
"Step= 4 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-64890"
"Step= 5 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-54890"
"Step= 6 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-44891"
"Step= 7 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-34893"
"Step= 8 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-24892"
"Step= 9 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-14890"
"Step= 10 X= 98000 Y= 185788 Z=-109233 T=-1049 R=-4890"
"Step= 11 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 4936"
"Step= 12 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 14936"
"Step= 13 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 24936"
"Step= 14 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 34936"
"Step= 15 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 44936"
"Step= 16 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 54935"
"Step= 17 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 64935"
"Step= 18 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 74936"
"Step= 19 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 84936"
"Step= 20 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 94936"
"Step= 21 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 104936"
"Step= 22 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 114936"
"Step= 23 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 124935"
"Step= 24 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 134936"
"Step= 25 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 144935"
"Step= 26 X= 98000 Y= 185788 Z=-109233 T=-1049 R= 154936"


Contact: 
Domingo Mery
dmery@ing.puc.cl
http://dmery.ing.puc.cl

(c) All rights reserved. These images can be used for educational and research purposes only.

