The GRIMA Database of X-ray images
Machine Intelligence Group (GRIMA)
Department of Computer Science
Pontificia Universidad Catolica de Chile

   set: X099 <Sink strainer> 
images: 36
  size: 574 x 768 pixels
   fmt: bmp

Original Filenames: sequence D
Rotation of axis R

<calibration object>
Images captured by Domingo Mery, 2000
YXLON, Hamburg, Germany

Position of Manipulator:
"Step= 0 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 289748"
"Step= 1 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 304750"
"Step= 2 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 319745"
"Step= 3 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 334749"
"Step= 4 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 349750"
"Step= 5 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 364749"
"Step= 6 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 379747"
"Step= 7 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 394750"
"Step= 8 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 409751"
"Step= 9 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 424741"
"Step= 10 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 439750"
"Step= 11 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 454750"
"Step= 12 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 469748"
"Step= 13 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 484751"
"Step= 14 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 499750"
"Step= 15 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 514744"
"Step= 16 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 529750"
"Step= 17 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 544751"
"Step= 18 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 559748"
"Step= 19 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 574750"
"Step= 20 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 589751"
"Step= 21 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 604749"
"Step= 22 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 619752"
"Step= 23 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 13060"
"Step= 24 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 28059"
"Step= 25 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 43060"
"Step= 26 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 58060"
"Step= 27 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 73048"
"Step= 28 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 88060"
"Step= 29 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 103062"
"Step= 30 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 118059"
"Step= 31 X= 136000 Y= 188747 Z=-110375 T=-1049 R= 133059"
"Step= 32 X= 136000 Y= 188747 Z=-105382 T=-1049 R= 133061"
"Step= 33 X= 136000 Y= 188747 Z=-115377 T=-1049 R= 133061"
"Step= 34 X= 136000 Y= 188747 Z=-112880 T=-1049 R= 133061"
"Step= 35 X= 136000 Y= 188747 Z=-107870 T=-1049 R= 133061"


Contact: 
Domingo Mery
dmery@ing.puc.cl
http://dmery.ing.puc.cl

(c) All rights reserved. These images can be used for educational and research purposes only.

